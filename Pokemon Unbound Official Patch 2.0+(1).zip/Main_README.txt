README
Patch the game with Pokemon Fire Red (U)(Squirrels)

Things to Know:
1. Cube Corp's interior and Glimmer Isle are not available yet.
2. Make sure your emulator's RTC is enabled, otherwise daily events won't be possible!
3. Take screenshots and save states of any bugs you find, and share them in Unbound's Discord server (https://discord.gg/k34Jm4T).
4. Known Bugs (if you encounter any and are playing on a PC, save the state and send to Skeli!):
-Please visit Discord https://discord.gg/k34Jm4T and see #main-known-bugs

6. What's unobtainable as of now?
The following Pokémon are still missing:
 • Mewtwo
 • Genesect
 • Marshadow
 • Meltan & Melmetal
 • Poipole & Nagandel

The following Mega Stones are still missing:
 • Mewtwonites

The following Z-Crystals are still missing:
 • Incinium Z

In order to obtain the missing Pokemon and (some) items, use these Mystery Gift codes on the second floor of any Pokemon Center after completing the game:
-Mewtwo:    6ZT5ZX7RN4KK
-Genesect:  7HY9JN6EE5YY
-Marshadow: 5GQ3CU5UZ7WS
-Meltan:    8VE4VF5PA4NH
-Poipole:   4QP1SH1BN8JF

Enjoy Playing!
